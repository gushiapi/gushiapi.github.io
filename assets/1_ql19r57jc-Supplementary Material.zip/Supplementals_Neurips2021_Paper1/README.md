## Submission Code for Paper1 (Differentiable Spike: Rethinking Gradient-Descent for Training Spiking Neural Networks)





### Prerequisites

 torch1.8 with cuda



### Dataset

We provide the drive link to download CIFAR10-DVS data:

train set: https://drive.google.com/file/d/1pzYnhoUvtcQtxk_Qmy4d2VrhWhy5R-t9/view?usp=sharing

test set: https://drive.google.com/file/d/1q1k6JJgVH3ZkHWMg2zPtrZak9jRP6ggG/view?usp=sharing



### Run

Please directly run the bash script, we also provide you with our experimental log file. 

