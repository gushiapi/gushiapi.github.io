class FP16_Optimizer:
    pass
