from .resnet import resnet20_cifar, resnet19_cifar, resnet20_cifar_modified
from .spike_model import SpikeModel