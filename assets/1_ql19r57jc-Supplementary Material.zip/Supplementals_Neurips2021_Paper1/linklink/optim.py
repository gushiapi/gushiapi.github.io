class FusedFP16SGD(object):

    def __init__(self, *args, **kwargs):
        pass

    @property
    def optimizer(self):
        return self
